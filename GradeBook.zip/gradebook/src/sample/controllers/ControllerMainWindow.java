package sample.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.stage.*;
import sample.DataBaseConnection;
import sample.model.Students;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.sql.*;

public class ControllerMainWindow {
    Connection connection = null;
    public ControllerMainWindow() {
        connection = new DataBaseConnection().connection();
    }
    ObservableList<Students> listCourse = FXCollections.observableArrayList();
    ObservableList<Students> check = FXCollections.observableArrayList();
    ObservableList<String> list = FXCollections.observableArrayList("java", "python","c#", "php");



    @FXML
    private ComboBox<String> comboBoxCourse;
    @FXML
    private Label labelCourse;
    @FXML
    private TableView<Students> tableCourse;
    @FXML
    private TableColumn<Students,String> date1Column;
    @FXML
    private TableColumn<Students,String> date2Column;
    @FXML
    private TableColumn<Students,String> date3Column;
    @FXML
    private TableColumn<Students,String> date4Column;
    @FXML
    private TableColumn<Students,String> fullNameColumn;

    private String courseName;


//ComboBox;
    public void actionComboBoxCourse() throws IOException {
//clear table;
        if (listCourse != null) {
            for (int i = 0; i < listCourse.size(); i++) {
                listCourse.remove(i--);
            }
        }
//      writing to object
        labelCourse.setText(comboBoxCourse.getValue());
        courseName = comboBoxCourse.getValue();
        try {
            String sqlSelect = "SELECT * FROM gradebook WHERE course = ?";
            PreparedStatement statement = connection.prepareStatement(sqlSelect);
            statement.setString(1, courseName);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                listCourse.add(new Students(
                        resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getString(4),
                        resultSet.getString(5),
                        resultSet.getString(6),
                        resultSet.getString(7)
                ));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

// show and edit info ;
    @FXML
    public void initialize() {
            comboBoxCourse.setItems(list);
            fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
            date1Column.setCellValueFactory(new PropertyValueFactory<>("date1"));
            date1Column.setCellFactory(TextFieldTableCell.<Students>forTableColumn());
            date1Column.setOnEditCommit((TableColumn.CellEditEvent<Students,String> event) -> {
            TablePosition<Students, String> pos = event.getTablePosition();
            String newFullName = event.getNewValue();
            int row = pos.getRow();
            Students course = event.getTableView().getItems().get(row);
            course.setDate1(newFullName);
        });

            date2Column.setCellValueFactory(new PropertyValueFactory<>("date2"));
            date2Column.setCellFactory(TextFieldTableCell.<Students>forTableColumn());
            date2Column.setOnEditCommit((TableColumn.CellEditEvent<Students,String> event) -> {
            TablePosition<Students, String> pos = event.getTablePosition();
            String newFullName = event.getNewValue();
            int row = pos.getRow();
            Students course = event.getTableView().getItems().get(row);
            course.setDate2(newFullName);
        });
            date3Column.setCellValueFactory(new PropertyValueFactory<>("date3"));
            date3Column.setCellFactory(TextFieldTableCell.<Students>forTableColumn());
            date3Column.setOnEditCommit((TableColumn.CellEditEvent<Students,String> event) -> {
            TablePosition<Students, String> pos = event.getTablePosition();
            String newFullName = event.getNewValue();
            int row = pos.getRow();
            Students course = event.getTableView().getItems().get(row);
            course.setDate3(newFullName);
        });
            date4Column.setCellValueFactory(new PropertyValueFactory<>("date4"));
            date4Column.setCellFactory(TextFieldTableCell.<Students>forTableColumn());
            date4Column.setOnEditCommit((TableColumn.CellEditEvent<Students,String> event) -> {
            TablePosition<Students, String> pos = event.getTablePosition();
            String newFullName = event.getNewValue();
            int row = pos.getRow();
            Students course = event.getTableView().getItems().get(row);
            course.setDate4(newFullName);
        });
        tableCourse.setEditable(true);
        tableCourse.setItems(listCourse);
        showPersonDetails(null);
        tableCourse.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->
                showPersonDetails(newValue));
    }

    private void showPersonDetails(Students students) {
        if (students != null) {
            System.out.println(students.getId() + " " + students.getFullName() + " " + students.getDate1() + " " +
                    students.getDate2() + " " + students.getDate3() + " " + students.getDate4());
        }
    }


//    save;
    public void buttonSave(ActionEvent event) throws IOException {
        try {
            Students students = tableCourse.getSelectionModel().getSelectedItem();
            String sqlUpdate = "UPDATE gradebook SET `2020-09-11` = ?, `2020-10-15` = ?, `2020-11-20` = ?, `2020-12-29` = ? WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(sqlUpdate);
            statement.setString(1, students.getDate1());
            statement.setString(2, students.getDate2());
            statement.setString(3, students.getDate3());
            statement.setString(4, students.getDate4());
            statement.setInt(5, students.getId());
            statement.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
//exit
    public void buttonExit(ActionEvent event){
        try {
            String sqlSelect = "SELECT * FROM gradebook WHERE course=?";
            PreparedStatement statement = connection.prepareStatement(sqlSelect);
            statement.setString(1, courseName);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                check.add(new Students(result.getInt(1), result.getString(2),
                        result.getString(3), result.getString(4),
                        result.getString(5), result.getString(6), result.getString(7)));

            }
//            checking save;
            if (check.equals(listCourse)){
                System.exit(0);
            }else {
                Parent root = FXMLLoader.load(getClass().getResource("/sample/view/info.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Exit");
                stage.getIcons().add(new Image(getClass().getResourceAsStream("/sample/icon.png")));
                stage.setScene(new Scene(root));
                stage.show();
                stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent windowEvent) {
                        windowEvent.consume();
                    }
                });
            }
        } catch (SQLException | IOException throwables) {
            throwables.printStackTrace();
        }
    }

//    ===========================================MenuBur===========================================;
//    exit;
    public void buttonMenuItemExit(){
        try {
            String sqlSelect = "SELECT * FROM gradebook WHERE course=?";
            PreparedStatement statement = connection.prepareStatement(sqlSelect);
            statement.setString(1, courseName);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                check.add(new Students(result.getInt(1), result.getString(2),
                        result.getString(3), result.getString(4),
                        result.getString(5), result.getString(6), result.getString(7)));
            }
//            checking save;
            if (check.equals(listCourse)){
                System.exit(0);
            }else {
                Parent root = FXMLLoader.load(getClass().getResource("/sample/view/info.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Exit");
                stage.getIcons().add(new Image(getClass().getResourceAsStream("/sample/icon.png")));
                stage.setScene(new Scene(root));
                stage.show();
                stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent windowEvent) {
                        windowEvent.consume();
                    }
                });
            }
        } catch (SQLException | IOException throwables) {
            throwables.printStackTrace();
        }
    }

//    export to file;
    public void buttonMenuItemExport() throws IOException {
        DirectoryChooser dir = new DirectoryChooser();
        dir.setTitle("Положение файла");
        File direct = dir.showDialog(new Stage());
        if ( direct != null){
            File file = new File(direct + "/"  + courseName + ".csv");
            file.createNewFile();

            PrintWriter printWriter = new PrintWriter(file,"windows-1251");
            for (Students students: listCourse) {
                printWriter.write(students.toString());
            }
            printWriter.close();
        }
    }
}



