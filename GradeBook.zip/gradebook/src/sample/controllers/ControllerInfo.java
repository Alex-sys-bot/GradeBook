package sample.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ControllerInfo {

    @FXML
    private Button idButtonCancel;


    public void buttonOk(){
        System.exit(0);
    }
    public void buttonCancel(){
        idButtonCancel.getScene().getWindow().hide();
    }

}
